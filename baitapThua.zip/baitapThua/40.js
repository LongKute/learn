//40. Tạo một `EventListener` để xử lý sự kiện nhấp chuột vào một nút HTML.
const button = document.getElementById("test_button");
button.addEventListener("click", function () {
  console.log("Hello");
});
// trong file index.html