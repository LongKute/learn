//6. Tạo một vòng lặp `for` để in ra các số từ 1 đến 10.
let a = 0;
for (let i = 0; i < 10; i++) {
  a++;
  console.log(a);
}
