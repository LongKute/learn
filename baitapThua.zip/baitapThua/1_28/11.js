// 11. Viết một chương trình đảo ngược một chuỗi.
let a = "Longkute";
let b = "";
for (let i = a.length - 1; i >= 0; i--) {
  b += a[i];
}
console.log(b);
