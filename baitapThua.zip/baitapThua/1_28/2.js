//2. Khai báo một biến với từ khóa `let` và gán cho nó một giá trị.
let a = 10;