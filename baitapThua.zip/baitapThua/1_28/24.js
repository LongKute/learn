// 24. Sử dụng `reduce()` để tính tổng các phần tử trong một mảng.
const arr = [3, 5, 7, 8, 2, 4];

console.log(arr.reduce((acc, current) => acc + current, 0));
