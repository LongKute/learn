//12. Tạo một đối tượng đại diện cho một cuốn sách với các thuộc tính như tiêu đề, tác giả và năm xuất bản
const book = {
  tilte: "Harry Potter",
  author: "J. K. Rowling",
  publish: "1997",
};
