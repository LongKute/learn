//Tạo một hàm nhận một số và trả về bình phương của nó.

function binh_Phuong(a) {
  a *= a;
  return a;
}

console.log(binh_Phuong(4));
