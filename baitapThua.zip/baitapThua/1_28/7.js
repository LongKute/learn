// 7. Tạo một hàm nhận 2 số và trả về số lớn hơn.

function check_Largest_Number(a, b) {
  if (a > b) {
    console.log("Số lớn nhất là số: " + a);
  } else {
    console.log("Số lớn nhất là số: " + b);
  }
}
check_Largest_Number(9, 2);
