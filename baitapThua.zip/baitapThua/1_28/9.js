// 9. Sử dụng phương thức `map()` để nhân đôi tất cả các phần tử trong một mảng số.

const a = [3, 6, 1, 4, 7, 9];
const b = a.map((x) => x * 2);
console.log(b);
