//1. Viết một chương trình in ra "Hello, World!" trong JavaScript.
console.log("Hello World");
