// 5. Tạo một mảng chứa tên của 5 quốc gia và in ra phần tử thứ ba.

const country = ["Vietnam", "Lao", "Campuchia", "Malaysia", "China"];

console.log(country[2]);
