//32. Sử dụng phương thức `every()` để kiểm tra xem tất cả các phần tử trong mảng có phải là số dương không.

const arr = [2, 3, 7, 4, 6, 5, 9, 10];

console.log(arr.every((x) => x > 0));
