//39. Sử dụng `setTimeout()` để thực hiện một công việc sau 5 giây.

function print_Hello(a) {
  console.log("Hello Long_kute");
}

setTimeout(print_Hello, 1000);
